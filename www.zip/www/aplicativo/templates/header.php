<html lang="es">
 <head>
 <meta charset="utf-8" />
 <meta http-equiv="x-ua-compatible" content="ie=edge" />
 <meta name="viewport" content="width=device-width, 
initial-scale=1" />

 <title>Aplicación CRUD PHP</title>
 
<link rel="stylesheet" type="text/css" href="/aplicativo/templates/estilos.css">

<link rel="stylesheet"
href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/
bootstrap.min.css" />

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <title>LOGIN</title>
    
</head>
<body>
</body>
</html> 