<?php require "templates/header.php"; ?>

<body class="login_bg">

    <div class="header" align="center">
    <h1 class="animate__animated animate__backInLeft">Sistema de login</h1>
    </div>

    <form class="form_login" action="validar.php" method="post">
        <div class="input-gruop">
            <label for="">Usuario</label>
            <input type="text" placeholder="ingrese su nombre" name="usuario">
        </div>

        <div class="input-gruop">
            <label for="">Contrase&ntilde;a</label>
            <input type="password" placeholder="ingrese su contraseña" name="contraseña">
        </div>
        <div class="input-gruop">
            <button type="submit" name="registrar" class="btn1" >Iniciar Sesi&oacute;n</button>
        </div>

    </form>

</body>

<?php require "templates/footer.php"; ?>