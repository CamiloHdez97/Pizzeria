<?php

return [
    
  'db' => [
    'host' => 'localhost',
    'user' => 'root',
    'pass' => 'paleto11',
    'name' => 'barlovento',
    'options' => [       
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]
 ]
];

?>