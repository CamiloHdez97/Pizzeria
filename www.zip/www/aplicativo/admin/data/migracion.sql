
CREATE DATABASE barlovento;

use barlovento;

CREATE TABLE usuarios (

    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(32) NOT NULL,
    apellido VARCHAR(32) NOT NULL,
    cc INT(10) NOT NULL,
    email VARCHAR(32) NOT NULL,
    username VARCHAR(20) NOT NULL UNIQUE KEY,
    password VARCHAR(32) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);

CREATE TABLE inventario (

    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    descripcion VARCHAR(32) NOT NULL,
    categoria VARCHAR(32) NOT NULL,
    valor INT(10) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);

CREATE TABLE proveedores (

    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa VARCHAR(32) NOT NULL,
    nit INT(12) NOT NULL,
    tel1 INT(12) NOT NULL,
    email VARCHAR(32) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);

CREATE TABLE productos (

    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombreProducto VARCHAR(32) NOT NULL,
    ingredientes VARCHAR(400) NOT NULL,
    categoriaProducto VARCHAR(32) NOT NULL,
    valorProducto INT(10) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);


CREATE USER 'lectura'@'localhost' IDENTIFIED with mysql_native_password BY '1234';
GRANT SELECT ON barlovento.productos TO 'lectura'@'localhost';
flush privileges;


CREATE USER 'usuario'@'localhost' IDENTIFIED with mysql_native_password BY 'uts123';
GRANT SELECT, INSERT, UPDATE, DELETE ON barlovento.* TO 'usuario'@'localhost';
flush privileges;
