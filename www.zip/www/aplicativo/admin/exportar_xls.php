<?php

$con = new mysqli("localhost","root","paleto11","barlovento");

$sql = "select * from usuarios";

$query = $con->query($sql);

if($query){
   while($r = $query->fetch_object()){

      echo $r->id.",";
      echo $r->nombre.",";
      echo $r->apellido.",";
      echo $r->cc.",";
      echo $r->email.",";
      echo $r->username."\n";
   }
}
   $filename = "export_usuarios_xls".date('Ymd') . ".xls";
   header("Content-Type: application/vnd.ms-excel");

   header("Content-Disposition: attachment; filename=".$filename);

?>
