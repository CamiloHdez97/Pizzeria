<?php

$con = new mysqli("localhost","root","paleto11","barlovento");

$sql = "select * from inventario";

$query = $con->query($sql);

if($query){
   while($r = $query->fetch_object()){

      echo $r->id.",";
      echo $r->descripcion.",";
      echo $r->categoria.",";
      echo $r->valor."\n";

   }
}
$filename = "export_inventario_xls".date('Ymd') . ".xls";
header("Content-Type: application/vnd.ms-excel");

header("Content-Disposition: attachment; filename=".$filename);
?>
