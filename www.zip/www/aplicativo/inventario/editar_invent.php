<?php
include 'funciones.php';

csrf();

    if (isset($_POST['submit']) && !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
    die();
}

$config = include 'config.php';

$resultado = [
    'error' => false,
    'mensaje' => ''
];

if (!isset($_GET['id'])) {
    $resultado['error'] = true;
    $resultado['mensaje'] = 'La descripcion no existe en la base de datos';
}

if (isset($_POST['submit'])) {

    try {
    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], 
    $config['db']['pass'], $config['db']['options']);

    $inventario = [
        "id" => $_GET['id'],
        "descripcion" => $_POST['descripcion'],
        "categoria" => $_POST['categoria'],
        "valor" => $_POST['valor']
    ];

    $consultaSQL = "UPDATE inventario SET
        descripcion = :descripcion,
        categoria = :categoria,
        valor = :valor,
        updated_at = NOW()
        WHERE id = :id";

    $consulta = $conexion->prepare($consultaSQL);
    $consulta->execute($inventario);

    } catch(PDOException $error) {
        $resultado['error'] = true;
        $resultado['mensaje'] = $error->getMessage();
    }
}

try {

    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . 
    $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], 
    $config['db']['pass'], $config['db']['options']);
 
    $id = $_GET['id'];
    $consultaSQL = "SELECT * FROM inventario WHERE id =" . $id;
    $sentencia = $conexion->prepare($consultaSQL);
    $sentencia->execute();

    $inventario = $sentencia->fetch(PDO::FETCH_ASSOC);
    
    if (!$inventario) {
        $resultado['error'] = true;
        $resultado['mensaje'] = 'No se ha encontrado la descripción';
    }

} catch(PDOException $error) {
    $resultado['error'] = true;
    $resultado['mensaje'] = $error->getMessage();
   }
?>


<?php include "../templates/header.php"; ?>

<?php
if ($resultado['error']) {
 ?>
    <div class="container mt-2">
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-danger" role="alert">
                    <?= $resultado['mensaje'] ?>
                </div>
            </div>
        </div>
    </div>
<?php
}
?>

<?php
if (isset($_POST['submit']) && !$resultado['error']) {?>
    <div class="container mt-2">
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-success" role="alert">
                    El inventario ha sido actualizado correctamente
                </div>
            </div>
        </div>
    </div>
<?php
}
?>


<?php
    if (isset($inventario) && $inventario) {
    ?>
    <body class="invent_bg">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="mt-4">Editando el inventario <?= 
                escapar($inventario['id']) . ' ' . 
                escapar($inventario['descripcion']) ?></h2>
                <hr>
            <form method="post">
                <div class="form-group">
                    <label for="descripcion">Descripción de Inventario</label>
                        <input type="text" name="descripcion" id="descripcion"
                            value="<?= escapar($inventario['descripcion']) ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label for="categoria">Categoría</label>
                        <input type="text" name="categoria" id="categoria" value="<?= escapar($inventario['categoria']) ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label for="valor">Valor</label>
                        <input type="text" name="valor" id="valor" value="<?= escapar($inventario['valor']) ?>" class="form-control">
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primary" value="Actualizar">
                        <a class="btn btn-primary" href="home_invent.php">Regresar al inicio</a>
                </div>
                <input name="csrf" type="hidden" value="<?php echo 
                escapar($_SESSION['csrf']); ?>">
            </form>
            </div>
        </div>
    </div>
    </body>
<?php
}
?>


<?php require "../templates/footer.php"; ?>