<?php

include 'funciones.php';

csrf();

    if (isset($_POST['submit']) && !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
    die();
    
}

if (isset($_POST['submit'])) {

    $resultado = [
        'error' => false,
        'mensaje' => 'El objeto' . escapar($_POST['descripcion']) . ' 
        ha sido agregado con éxito'
    ];
 
    $config = include 'config.php';

    try {
    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname='
    . $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], 
    $config['db']['pass'], $config['db']['options']);

    $inventario = array(
        "descripcion" => $_POST['descripcion'],
        "categoria" => $_POST['categoria'],
        "valor" => $_POST['valor'],
    
        );
      
//Crear array con los datos

    $consultaSQL = "INSERT INTO inventario (descripcion, categoria, valor)";
    $consultaSQL .= "values (:" . implode(", :", array_keys($inventario)) . ")";

//Ejecutar sentencia sql

    $sentencia = $conexion->prepare($consultaSQL);
    $sentencia->execute($inventario);

// Código que insertará un producto

    } catch(PDOException $error) {
        $resultado['error'] = true;
        $resultado['mensaje'] = $error->getMessage();
    }

}
?>

<?php include "../templates/header.php"; ?>

<?php
if (isset($resultado)) {
 ?>
    <div class="container mt-3">
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-<?= $resultado['error'] ?'danger' : 'success' ?>" role="alert">
                    <?= $resultado['mensaje'] ?>
                </div>
            </div>
        </div>
    </div>

    <?php
}
?>

<body class="invent_bg">

<div class="container">

    <div class="row">

        <div class="col-md-12">
            
            <h2 class="mt-4">Registrar en inventario</h2>
            <hr>
  
            <form method="post">
                <div class="form-group">
                    <label for="descripcion">descripcion de registro</label>
                    <input type="text" name="descripcion" id="descripcion"class="form-control">
                </div>
                <div class="form-group">
                    <label for="categoria">Categoria del registro</label>
                    <input type="text" name="categoria" id="categoria" class="form-control">
                </div>

                <div class="form-group">
                    <label for="valor">valor</label>
                    <input type="text" name="valor" id="valor" class="form-control">
                </div>

                <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primary" value="Agregar">
                    <a class="btn btn-primary"
                    href="home_invent.php">Regresar al inicio</a>
                </div>
                <input name="csrf" type="hidden" value="<?php echo 
                escapar($_SESSION['csrf']); ?>">
            </form>

        </div>
    </div>
</div>
</body>

<?php include "../templates/footer.php"; ?>
