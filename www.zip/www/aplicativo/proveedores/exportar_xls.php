<?php

$con = new mysqli("localhost","root","paleto11","barlovento");

$sql = "select * from proveedores";

$query = $con->query($sql);

if($query){
   while($r = $query->fetch_object()){

      echo $r->id.",";
      echo $r->empresa.",";
      echo $r->nit.",";
      echo $r->tel1.",";
      echo $r->email."\n";

   }
}
$filename = "export_proveedores_xls".date('Ymd') . ".xls";
header("Content-Type: application/vnd.ms-excel");

header("Content-Disposition: attachment; filename=".$filename);

?>