<?php
include 'funciones.php';

csrf();

    if (isset($_POST['submit']) && !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
    die();
}

$config = include 'config.php';

$resultado = [
    'error' => false,
    'mensaje' => ''
];

if (!isset($_GET['id'])) {
    $resultado['error'] = true;
    $resultado['mensaje'] = 'El proveedor no existe';
}

if (isset($_POST['submit'])) {

    try {
    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], 
    $config['db']['pass'], $config['db']['options']);

    $proveedor = [
        "id" => $_GET['id'],
        "empresa" => $_POST['empresa'],
        "nit" => $_POST['nit'],
        "tel1" => $_POST['tel1'],
        "email" => $_POST['email']
    ];

    $consultaSQL = "UPDATE proveedores SET
        empresa = :empresa,
        nit = :nit,
        tel1 = :tel1,
        email = :email,
        updated_at = NOW()
        WHERE id = :id";

    $consulta = $conexion->prepare($consultaSQL);
    $consulta->execute($proveedor);

    } catch(PDOException $error) {
        $resultado['error'] = true;
        $resultado['mensaje'] = $error->getMessage();
    }
}

try {

    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . 
    $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], 
    $config['db']['pass'], $config['db']['options']);
 
    $id = $_GET['id'];
    $consultaSQL = "SELECT * FROM proveedores WHERE id =" . $id;
    $sentencia = $conexion->prepare($consultaSQL);
    $sentencia->execute();

    $proveedor = $sentencia->fetch(PDO::FETCH_ASSOC);
    
    if (!$proveedor) {
        $resultado['error'] = true;
        $resultado['mensaje'] = 'No se ha encontrado el Proveedor';
    }

} catch(PDOException $error) {
    $resultado['error'] = true;
    $resultado['mensaje'] = $error->getMessage();
   }
?>

<?php include "../templates/header.php"; ?>

<?php
if ($resultado['error']) {
 ?>
    <div class="container mt-2">
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-danger" role="alert">
                    <?= $resultado['mensaje'] ?>
                </div>
            </div>
        </div>
    </div>
<?php
}
?>

<?php
if (isset($_POST['submit']) && !$resultado['error']) {?>
    <div class="container mt-2">
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-success" role="alert">
                    El Proveedor ha sido actualizado correctamente
                </div>
            </div>
        </div>
    </div>
<?php
}
?>


<?php
    if (isset($proveedor) && $proveedor) {
    ?>
    <body class="provee_bg">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="mt-4">Editando el Proveedor <?= 
                escapar($proveedor['id']) . ' ' . 
                escapar($proveedor['empresa']) ?></h2>
                <hr>
            <form method="post">
                <div class="form-group">
                    <label for="empresa">Nombre de Proveedor</label>
                        <input type="text" name="empresa" id="empresa"
                            value="<?= escapar($proveedor['empresa']) ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label for="nit">NIT de Proveedor</label>
                        <input type="text" name="nit" id="nit" value="<?= escapar($proveedor['nit']) ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label for="tel1">Numero de Contacto</label>
                        <input type="text" name="tel1" id="tel1" value="<?= escapar($proveedor['tel1']) ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label for="email">E-mail</label>
                        <input type="email" name="email" id="email" value="<?= escapar($proveedor['email']) ?>" class="form-control">
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primary" value="Actualizar">
                        <a class="btn btn-primary" href="home_provee.php">Regresar al inicio</a>
                </div>
                <input name="csrf" type="hidden" value="<?php echo 
                escapar($_SESSION['csrf']); ?>">
            </form>
            </div>
        </div>
    </div>
    </body>
<?php
}
?>

<?php require "../templates/footer.php"; ?>