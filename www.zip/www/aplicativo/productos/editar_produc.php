<?php
include 'funciones.php';

csrf();

    if (isset($_POST['submit']) && !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
    die();
}

$config = include 'config.php';

$resultado = [
    'error' => false,
    'mensaje' => ''
];

if (!isset($_GET['id'])) {
    $resultado['error'] = true;
    $resultado['mensaje'] = 'El Producto no existe';
}

if (isset($_POST['submit'])) {

    try {
    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], 
    $config['db']['pass'], $config['db']['options']);

    $producto = [
        "id" => $_GET['id'],
        "nombreProducto" => $_POST['nombreProducto'],
        "ingredientes" => $_POST['ingredientes'],
        "categoriaProducto" => $_POST['categoriaProducto'],
        "valorProducto" => $_POST['valorProducto']
    ];

    $consultaSQL = "UPDATE productos SET
        nombreProducto = :nombreProducto,
        ingredientes = :ingredientes,
        categoriaProducto = :categoriaProducto,
        valorProducto = :valorProducto,
        updated_at = NOW()
        WHERE id = :id";

    $consulta = $conexion->prepare($consultaSQL);
    $consulta->execute($producto);

    } catch(PDOException $error) {
        $resultado['error'] = true;
        $resultado['mensaje'] = $error->getMessage();
    }
}

try {

    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . 
    $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], 
    $config['db']['pass'], $config['db']['options']);
 
    $id = $_GET['id'];
    $consultaSQL = "SELECT * FROM productos WHERE id =" . $id;
    $sentencia = $conexion->prepare($consultaSQL);
    $sentencia->execute();

    $producto = $sentencia->fetch(PDO::FETCH_ASSOC);
    
    if (!$producto) {
        $resultado['error'] = true;
        $resultado['mensaje'] = 'No se ha encontrado el producto';
    }

} catch(PDOException $error) {
    $resultado['error'] = true;
    $resultado['mensaje'] = $error->getMessage();
   }
?>

<?php include "../templates/header.php"; ?>

<?php
if ($resultado['error']) {
 ?>
    <div class="container mt-2">
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-danger" role="alert">
                    <?= $resultado['mensaje'] ?>
                </div>
            </div>
        </div>
    </div>
<?php
}
?>

<?php
if (isset($_POST['submit']) && !$resultado['error']) {?>
    <div class="container mt-2">
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-success" role="alert">
                    El Producto ha sido actualizado correctamente
                </div>
            </div>
        </div>
    </div>
<?php
}
?>


<?php
    if (isset($producto) && $producto) {
    ?>
    <body class="product_bg">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="mt-4">Editando el Producto <?= 
                escapar($producto['nombreProducto']) . ' ' . 
                escapar($producto['ingredientes']) ?></h2>
                <hr>
            <form method="post">
                <div class="form-group">
                    <label for="nombreProducto">Nombre de Producto</label>
                        <input type="text" name="nombreProducto" id="nombreProducto"
                            value="<?= escapar($producto['nombreProducto']) ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label for="ingredientes">Ingredientes</label>
                        <input type="text" name="ingredientes" id="ingredientes" value="<?= escapar($producto['ingredientes']) ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label for="categoriaProducto">Categoria de Producto</label>
                        <input type="categoriaProducto" name="categoriaProducto" id="categoriaProducto" value="<?= escapar($producto['categoriaProducto']) ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label for="valorProducto">Valor de Producto</label>
                        <input type="text" name="valorProducto" id="valorProducto" value="<?= escapar($producto['valorProducto']) ?>" class="form-control">
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primary" value="Actualizar">
                        <a class="btn btn-primary" href="home_produc.php">Regresar al inicio</a>
                </div>
                <input name="csrf" type="hidden" value="<?php echo 
                escapar($_SESSION['csrf']); ?>">
            </form>
            </div>
        </div>
    </div>
    </body>
<?php
}
?>


<?php require "../templates/footer.php"; ?>