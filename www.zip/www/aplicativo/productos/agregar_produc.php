<?php

include 'funciones.php';

csrf();

    if (isset($_POST['submit']) && !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
    die();
    
}

if (isset($_POST['submit'])) {

    $resultado = [
        'error' => false,
        'mensaje' => 'El producto ' . escapar($_POST['nombreProducto']) . ' 
        ha sido agregado con éxito'
    ];
 
    $config = include 'config.php';

    try {
    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname='
    . $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], 
    $config['db']['pass'], $config['db']['options']);

    $producto = array(
        "id" => $_POST['id'],
        "nombreProducto" => $_POST['nombreProducto'],
        "ingredieentes" => $_POST['ingredientes'],
        "categoriaProducto" => $_POST['categoriaProducto'],
        "valorProducto" => $_POST['valorProducto']
        );
      
//Crear array con los datos

    $consultaSQL = "INSERT INTO productos (id, nombreProducto, ingredientes, categoriaProducto,valorProducto)";
    $consultaSQL .= "values (:" . implode(", :", array_keys($producto)) . ")";

//Ejecutar sentencia sql

    $sentencia = $conexion->prepare($consultaSQL);
    $sentencia->execute($producto);

// Código que insertará un producto

    } catch(PDOException $error) {
        $resultado['error'] = true;
        $resultado['mensaje'] = $error->getMessage();
    }

}
?>

<?php include "../templates/header.php"; ?>

<?php
if (isset($resultado)) {
 ?>
    <div class="container mt-3">
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-<?= $resultado['error'] ?'danger' : 'success' ?>" role="alert">
                    <?= $resultado['mensaje'] ?>
                </div>
            </div>
        </div>
    </div>

    <?php
}
?>

<body class="product_bg">

<div class="container">

    <div class="row">

        <div class="col-md-12">
            
            <h2 class="mt-4">Agregar producto</h2>
            <hr>
  
            <form method="post">
                
                <div class="form-group">
                    <label for="nombreProducto">Nombre de Producto</label>
                    <input type="text" name="nombreProducto" id="nombreProducto" class="form-control">
                </div>

                <div class="form-group">
                    <label for="ingredientes">Ingredientes</label>
                    <input type="text" name="ingredientes" id="ingredientes" class="form-control">
                </div>

                <div class="form-group">
                    <label for="categoriaProducto">Categoria</label>
                    <input type="text" name="categoriaProducto" id="categoriaProducto" class="form-control">
                </div>

                <div class="form-group">
                    <label for="valorProducto">Valor de Producto</label>
                    <input type="text" name="valorProducto" id="valorProducto" class="form-control">
                </div>

                <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primary" value="Agregar">
                    <a class="btn btn-primary"
                    href="home_produc.php">Regresar al inicio</a>
                </div>
                <input name="csrf" type="hidden" value="<?php echo 
                escapar($_SESSION['csrf']); ?>">
            </form>

        </div>
    </div>
</div>
</body>

<?php include "../templates/footer.php"; ?>
