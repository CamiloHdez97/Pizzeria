<?php
include 'funciones.php';

csrf();

    if (isset($_POST['submit']) && !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
    die();
    
}

$error = false;
$config = include 'config.php';

try {

    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . 
    $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], 
    $config['db']['pass'], $config['db']['options']);

    $consultaProductos = "SELECT * FROM productos";
    $consultaProvee = "SELECT * FROM proveedores";
    $consultaInventario = "SELECT * FROM inventario";

    $ResultProductos = $conexion->prepare($consultaProductos);
    $consultaProvee = $conexion->prepare($consultaProvee);
    $ResultInventario = $conexion->prepare($consultaInventario);

    $ResultProductos->execute();
    $consultaProvee->execute();
    $ResultInventario->execute();
    

    $Productos = $ResultProductos->fetchAll();
    $Provee= $consultaProvee->fetchAll();
    $Inventario = $ResultInventario->fetchAll();

    } catch(PDOException $error) {
        $error= $error->getMessage();
        }
?>

<?php include "templates/header.php"; ?>

<body class="home_bg">
<a href="https://wa.me/573134473622?text=Asunto%20Interno" class="whatsapp" target="_blank"> <i class="fa fa-whatsapp whatsapp-icon"></i></a>
    
        <div class="menu">
        <img src="templates/img/logo.jpg" width=8%>       
            <nav>    
                <ul>
                    <li><a href="productos/home_produc.php">Administrar productos</a></il>
                    <li><a href="proveedores/home_provee.php">Administrar Proveedores</a></il>
                    <li><a href="inventario/home_invent.php">Administrar Inventario</a></il>
                    <li><a href="/">Cerra Sesión</a></il>
                </ul>
            </nav>
        </div>


        <main>
            <div class="container" id="menu">
                <div class="row">
                    <div class="col text-center">
                        <br>
                        <h3>Productos</h3>

                        <table class="tabla_init">
                            <th>Descripción</th>
                            <th>Ingredientes</th> 
                            <th>Categoria</th> 
                            <th>Precios $</th>    

                        <?php
                            if ($Productos && $ResultProductos->rowCount() > 0) {
                                foreach ($Productos as $fila) {
                        ?>
                            <tr class="tr">
                            <td class="td"><?php echo escapar($fila["nombreProducto"]);?></td>
                            <td class="td"><?php echo escapar($fila["ingredientes"]); ?></td>
                            <td class="td"><?php echo escapar($fila["categoriaProducto"]); ?></td>
                            <td class="td"><?php echo escapar($fila["valorProducto"]); ?></td>
                            </tr>
                            <?php
                            }
                            }
                        ?>

                        </table>

                    </div>
                    <div class="col text-center">
                        <br>
                        <h3>Proveedores</h3>

                        <table class="tabla_init">
                            <th>Descripción</th>
                            <th>Nit</th> 
                            <th>Celular</th>    
                            <th>Correo</th> 

                        <?php
                            if ($Provee && $consultaProvee->rowCount() > 0) {
                                foreach ($Provee as $fila) {
                        ?>
                            <tr class="tr">
                            <td class="td"><?php echo escapar($fila["empresa"]);?></td>
                            <td class="td"><?php echo escapar($fila["nit"]); ?></td>
                            <td class="td"><?php echo escapar($fila["tel1"]); ?></td>
                            <td class="td"><?php echo escapar($fila["email"]); ?></td>
                            </tr>
                            <?php
                            }
                            }
                        ?>
                        </table>
                    </div>
                    <div class="col text-center">
                        <br>
                        <h3>Inventario</h3>

                        <table class="tabla_init">
                            <th>Descripción</th>
                            <th>Categoria</th> 
                            <th>Valor $</th>   
                        <?php
                            if ($Inventario && $ResultInventario->rowCount() > 0) {
                                foreach ($Inventario as $fila) {
                        ?>
                            <tr class="tr">
                            <td class="td"><?php echo escapar($fila["descripcion"]);?></td>
                            <td class="td"><?php echo escapar($fila["categoria"]); ?></td>
                            <td class="td"><?php echo escapar($fila["valor"]); ?></td>
                            </tr>
                            <?php
                            }
                            }
                        ?>
                        </table>
                    </div>
                </div>
                <br>
                <div class="row">
                </div>

            </div>
            <br>
        </main>

        
        <footer class="footer">
            <div class="container">
                <div class="row py-3">
                    <div class="col-12 text-center">
                        <p class="mb-0 lead text-white">barlovento artesanal. Todos los Derechos Reservados. 2021 &copy;</p>
                    </div>
                </div>
            </div>
        </footer>
    </body>

</body>

<?php include "templates/footer.php"; ?>