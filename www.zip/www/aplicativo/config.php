<?php

return [
    
  'db' => [
    'host' => 'localhost',
    'user' => 'usuario',
    'pass' => 'uts123',
    'name' => 'barlovento',
    'options' => [       
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]
 ]
];

?>