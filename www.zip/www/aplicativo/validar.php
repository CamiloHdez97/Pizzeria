
<?php

$usuario = $_POST['usuario'];
$password = $_POST['contraseña'];

session_start();

$_SESSION['usuario']=$usuario;

if($usuario == 'admin' and $password == 'paleto11'){

    $conexion=mysqli_connect("localhost","root","paleto11","barlovento");
    header("location:admin/principal.php");

}else{

    $conexion=mysqli_connect("localhost","root","paleto11","barlovento");

    $consulta = "SELECT*FROM usuarios where username='$usuario' and password='$password'";

    $resultado = mysqli_query($conexion,$consulta);

    $filas=mysqli_num_rows($resultado);

    if($filas){

        header("location:home.php");

    }else{
        ?>
        <?php
        include("login.php");
      ?>
 
      <H2 class="bad">ERROR DE CREDENCIALES</H2>
      <?php
  }
}
mysqli_free_result($resultado);
mysqli_close($conexion);