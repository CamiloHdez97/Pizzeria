<?php
include 'funciones.php';

csrf();

    if (isset($_POST['submit']) && !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
    die();
    
}

$error = false;
$config = include 'config.php';

try {

    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . 
    $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], 
    $config['db']['pass'], $config['db']['options']);

    $consultaPizza = "SELECT * FROM productos WHERE categoriaProducto LIKE 'PIZZA'";
    $consultaLasaña = "SELECT * FROM productos WHERE categoriaProducto LIKE 'LASAÑA'";
    $consultaPasabocas = "SELECT * FROM productos WHERE categoriaProducto LIKE 'PASABOCAS'";

    $ResultPizza = $conexion->prepare($consultaPizza);
    $ResultLasaña = $conexion->prepare($consultaLasaña);
    $ResultPasabocas = $conexion->prepare($consultaPasabocas);

    $ResultPizza->execute();
    $ResultLasaña->execute();
    $ResultPasabocas->execute();
    

    $Pizza = $ResultPizza->fetchAll();
    $Lasaña= $ResultLasaña->fetchAll();
    $Pasabocas = $ResultPasabocas->fetchAll();

    } catch(PDOException $error) {
        $error= $error->getMessage();
        }
?>

<?php include "aplicativo/templates/header.php"; ?>

<body class="index_bg">
<a href="https://wa.me/573134473622?text=Me%20gustaría%20hacer%20un%20pedido%20" class="whatsapp" target="_blank"> <i class="fa fa-whatsapp whatsapp-icon"></i></a>
    
        <div class="menu">
        <img src="aplicativo/templates/img/logo.jpg" width=8%>       
            <nav>    
                <ul>
                    <li><a href="https://www.instagram.com/barlovento.artesanal/" target="black">¡Síguenos en Instagram!</a></li>
                    <li><a href="aplicativo/login.php">Iniciar Sesión</a></il>
                </ul>
            </nav>
        </div>
        <main>
            <div class="container" id="menu">
                <h1 class="text-center">Nuestro Menú</h1>
                <hr>
                <div class="row">
                    <div class="col text-center">
                        <img src="aplicativo/templates/img/pizza.jpg" alt="Pizza" width="60%">
                        <br>
                        <h3>Pizza</h3>
                        <hr>
                        <table class="tabla_init">
                            <th>Descripción</th>
                            <th>Ingredientes</th> 
                            <th>Precios $</th>    

                        <?php
                            if ($Pizza && $ResultPizza->rowCount() > 0) {
                                foreach ($Pizza as $fila) {
                        ?>
                            <tr class="tr">
                            <td><?php echo escapar($fila["nombreProducto"]);?></td>
                            <td><?php echo escapar($fila["ingredientes"]); ?></td>
                            <td><?php echo escapar($fila["valorProducto"]); ?></td>
                            </tr>
                            <?php
                            }
                            }
                        ?>

                        </table>

                    </div>
                    <div class="col text-center">
                        <img src="aplicativo/templates/img/lasaña.jpg" alt="Lasaña" width="60%">
                        <br>
                        <h3>Lasaña</h3>
                        <hr>
                        <table class="tabla_init">
                            <th>Descripción</th>
                            <th>Ingredientes</th> 
                            <th>Precios $</th>    

                        <?php
                            if ($Lasaña && $ResultLasaña->rowCount() > 0) {
                                foreach ($Lasaña as $fila) {
                        ?>
                            <tr class="tr">
                            <td><?php echo escapar($fila["nombreProducto"]);?></td>
                            <td><?php echo escapar($fila["ingredientes"]); ?></td>
                            <td><?php echo escapar($fila["valorProducto"]); ?></td>
                            </tr>
                            <?php
                            }
                            }
                        ?>
                        </table>
                    </div>
                    <div class="col text-center">
                    <img src="aplicativo/templates/img/panzerotti.jpg" alt="Panzerotti" width="60%">
                        <br>
                        <h3>Pasabocas</h3>
                        <hr>
                        <table class="tabla_init">
                            <th>Descripción</th>
                            <th>Ingredientes</th> 
                            <th>Precios $</th>   
                        <?php
                            if ($Pasabocas && $ResultPasabocas->rowCount() > 0) {
                                foreach ($Pasabocas as $fila) {
                        ?>
                            <tr class="tr">
                            <td><?php echo escapar($fila["nombreProducto"]);?></td>
                            <td><?php echo escapar($fila["ingredientes"]); ?></td>
                            <td><?php echo escapar($fila["valorProducto"]); ?></td>
                            </tr>
                            <?php
                            }
                            }
                        ?>
                        </table>
                    </div>
                </div>
                <br>
                <div class="row">
                </div>

            </div>
            <br>
        </main>
        <footer class="footer">
            <div class="container">
                <div class="row py-3">
                    <div class="col-12 text-center">
                        <p class="mb-0 lead text-white">barlovento artesanal. Todos los Derechos Reservados. 2021 &copy;</p>
                    </div>
                </div>
            </div>
        </footer>
    </body>

</body>

<?php include "aplicativo/templates/footer.php"; ?>