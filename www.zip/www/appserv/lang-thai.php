<?php
/**************************************************************************/
/* AppServ Language: The Future of the Web                                */
/**************************************************************************/
define("_CHARSET","utf-8");
define("_ABOUT","เกี่ยวกับโปรแกรม");
define("_FOR","สำหรับ");
define("_IS","คือ โปรแกรมที่รวบรวมโอเพ่นซอร์สซอฟท์แวร์หลายๆ อย่างเข้าด้วยกัน โดยมี :");
define("_APACHE","Apache Web Server");
define("_MYSQL","MySQL Database");
define("_PERL","Perl");
define("_PHP","PHP Script Language");
define("_PHPINFO","PHP Information");
define("_ZENDOPT","Zend Optimizer");
define("_PHPMYADMIN","phpMyAdmin Database Manager");
define("_PHPNUKE","พีเอชพีนู๊ค เว็บสำเร็จรูป");
define("_PHPBB","พีเอชพีบีบี เว็บบอร์ด");
define("_VERSION","เวอร์ชั่น");
define("_CHANGELOG","มีอะไรใหม่");
define("_README","โปรดอ่านคำแนะนำวิธีใช้งาน");
define("_AUTHOR","เกี่ยวกับผู้จัดทำ");
define("_COPYING","เกี่ยวกับลิขสิทธิ์");
define("_SITE","โฮมเพจ");
define("_LANG","เปลี่ยนภาษา");
define("_SLOGAN","สร้างเว็บเซิร์ฟเวอร์, ดาต้าเบสเซิร์ฟเวอร์ง่ายๆ ด้วย AppServ :-) ");
define("_OS","วินโดวส์");
define("_OFSITE","เว็บไซต์หลัก");
define("_HSUP","เว็บโฮสติ้ง");
?>