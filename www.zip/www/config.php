<?php

return [
    
  'db' => [
    'host' => 'localhost',
    'user' => 'lectura',
    'pass' => '1234',
    'name' => 'barlovento',
    'options' => [       
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]
 ]
];

?>